package com.shab.log4j;

import java.io.File;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;;

public class Log4jExample {
	 static Logger logger = Logger.getLogger(Log4jExample.class);
	
	public static void main(String[] args) {
		
		String log4jConfigFile = System.getProperty("user.dir") + File.separator + "src" + File.separator + "resources"
				+ File.separator + "log4j.properties";
		PropertyConfigurator.configure(log4jConfigFile);
		
		logger.debug("hi, this is debug");
		
	}

}

